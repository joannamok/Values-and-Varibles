var yearBorn = 1955;

console.log("Hello World!")
console.log(yearBorn)

alert(yearBorn);