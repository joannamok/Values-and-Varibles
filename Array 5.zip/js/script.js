//Arrays
var muppetNames = ["Kermit", "Miss Piggy"]; //indexes 0,1,2,3

muppetNames[1] = "Rizzo";
muppetNames[2] = "Fozzy";

var num = 1;
console.log(muppetNames[num]);