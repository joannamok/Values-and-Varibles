var yearBorn = 1955;

console.log(yearBorn)