var age = 38;

var isStudent = false;

var firstName = "Joanna";

'I don\'t know'// using backslash keeps string from being broken.

'I don\'t know' \n 'You\'ll have to speak to the professor' // backslash n represents a new line