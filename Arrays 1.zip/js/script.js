//Arrays
var muppetNames = ["Kermit", "Miss Piggy", "Gonzo", "Rizzo"]; //indexes 0,1,2,3

console.log(muppetNames)