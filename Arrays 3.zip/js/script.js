//Arrays
var muppetNames = ["Kermit", "Miss Piggy"]; //indexes 0,1,2,3

muppetNames[1] = "Rizzo";
console.log(muppetNames[1]);